def calc(toponym):
    toponym_coodrinates = toponym["Point"]["pos"]
    toponym_longitude, toponym_lattitude = toponym_coodrinates.split(" ")
    left, bottom = toponym["boundedBy"]["Envelope"]["lowerCorner"].split()
    right, top = toponym["boundedBy"]["Envelope"]["upperCorner"].split()
    long, high = float(right) - float(left), float(top) - float(bottom)
    return ",".join([toponym_longitude, toponym_lattitude]), ",".join([str(long), str(high)])